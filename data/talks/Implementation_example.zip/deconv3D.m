%% Load data
% Set names for data directories and filename start
dataname = { ['CElegans-CY3'  filesep 'Data-CY3-Z' ], ...
             ['CElegans-DAPI' filesep 'Data-DAPI-Z'], ...
             ['CElegans-FITC' filesep 'Data-FITC-Z'] };
psfname  = { ['PSF-CElegans-CY3'  filesep 'PSF-CY3-Z' ], ...
             ['PSF-CElegans-DAPI' filesep 'PSF-DAPI-Z'], ...
             ['PSF-CElegans-FITC' filesep 'PSF-FITC-Z'] };
         
% Sequence length and image dimensions
nz = 104; ny = 712; nx = 672; 

% Select index (1: CY3, 2: DAPI, 3: FITC)
ind = 1;

% Preallocate space for data and PSF
y   = zeros( ny, nx, nz );
psf = zeros( ny, nx, nz );

% Load data and PSF (note: same size!)
for ii = 0:nz-1
    y(:,:,ii+1) =   double( loadtiff( ...
                   sprintf( '%s%03d.tif', dataname{ind}, ii ) ) );
    psf(:,:,ii+1) = double( loadtiff( ...
               sprintf( '%s%03d.tif', psfname{ind}, ii  ) ) );
end

% Normalize data and PSF
psf = psf / sum( psf, 'all' );
maxy = max( y, [], 'all' ); y = y / maxy;

% Visualize PSF
% volumeViewer( psf, 'ScaleFactors', [1, 1, 3.1] )

% Pad PSF to make the resulting circular convolution (FFT based) equivalent
% to the linear convolution. Strictly, we would need padding in the XY 
% directions too, but we disregard it as there is less signal at those 
% boundaries.
pad_half_size = [0, 0, 52];
% Find efficient FFT sizes
var_size = fft_best_dim( [ny, nx, nz] + 2 * pad_half_size );
% Pad the PSF
pad_half_size = (var_size - [ny, nx, nz])/2;
psf = padarray( psf, pad_half_size, 0, 'both' );
% Place center of the PSF at the (1,1,1) coordinate to prevent unwanted
% shift in the convolution
psf = ifftshift( psf );

% GPU handling if selected (Warning! Very large GPU needed)
% 0: CPU, 1: GPU (Mathworks), 2: GPU (CudaMat)
useGPU( 0 )
% Convert according to selection
y   = gpuCpuConverter( y   );
psf = gpuCpuConverter( psf );

%% Operators
% System matrix / forward operator
% The convolution will be performed in the Fourier domain
H = LinOpConv( fftn( psf ) );
% Regularization operator (to a sparse domain)
% Gradient operator for TV regularization
L = LinOpGrad( var_size );
% Identity operator to impose constraints through regularization
I = LinOpIdentity( var_size );
% Store (noperator outputs
H.memoizeOpts.apply = true; L.memoizeOpts.apply = true;

%% Cost function
% Least squares data fidelity term
l2_cost = CostL2( [ny, nx, nz], y );
% Operator to extract the 'valid' part of the convolution
% (see zero-padding in the "Load Data" section), i.e.,
% the one to be compared to the data
S = LinOpSelectorPatch( var_size, ...
                        pad_half_size + 1, ...
                        var_size - pad_half_size );
% Compose to create the cost function (inputs will be passed through S and
% then through l2_cost)
least_squares_cost = l2_cost * S;

%% Regularization
% Mixed norm (group sparisty) to get an isotropic total variation (TV) from
% the gradient
mixed_norm_regularizer = CostMixNorm21( [var_size, 3], 4 );
% Regularization parameter TV
lambda_TV = 2e-6;
% Non-negativity indicator function to preserve physical meaning
nnegativity_regularizer = CostNonNeg( var_size );

%% Configure ADMM
% Linear operators of each splitting domain
linear_ops = { H, L, I };
% Cost functions for each of the domains
cost_functions = { least_squares_cost, ...
                   lambda_TV * mixed_norm_regularizer, ...
                   nnegativity_regularizer };
% Penalty parameters for ADMM
mus = 1e-3 * ones( 3 );
% Create ADMM object
ADMM = OptiADMM( [], cost_functions, linear_ops, mus );
% Configure convergence criteria
% 300 iterations or relative cost under 1e-4 or relative step under 1e-4
ADMM.maxiter = 300;
ADMM.CvOp    = TestCvgCombine( 'CostRelative', 1e-4, ...
                               'StepRelative', 1e-4 );
% Configure algorithm output while running
% Report costs (1 and 2 in cost_functions, corresponding to least squares 
% and TV regularizer), but don't store them, 30 times in the number of 
% maximum iterations.
ADMM.OutOp   = OutputOpti( true, [], round( ADMM.maxiter / 30 ), [1, 2] );
ADMM.ItUpOut = ADMM.maxiter / 30;

%% Run ADMM
% With initialization at zero
ADMM.run( zeros_( var_size ) );
% Extract and store results with time stamp
result = gather( S.apply( ADMM.xopt ) );
t = clock;
saveastiff( result, ...
  sprintf( '%s-result-%d-%d-%d_%d-%d.tiff', dataname{ind}, ...
            t(1), t(2), t(3), t(4), t(5) ) );




