url = 'https://github.com/Biomedical-Imaging-Group/GlobalBioIm/archive/master.zip';
filename = 'master.zip';

fprintf( '\tDownloading and setting path for GlobalBioIm...\n' );
websave( filename, url ); unzip( filename ); delete( filename);
cd( 'GlobalBioIm-master' ); setGlobalBioImPath; cd( '..' )
fprintf( 'Done.' );