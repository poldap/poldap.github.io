yes_or_no = input( 'This will take 600 MB in your disk, continue? (Y/n)\n', 's' );
if yes_or_no ~= 'Y'
    return;
end

filenames = { 'CElegans-CY3.zip', 'CElegans-DAPI.zip', 'CElegans-FITC.zip', ...
'PSF-CElegans-CY3.zip', 'PSF-CElegans-DAPI.zip', 'PSF-CElegans-FITC.zip' };

fprintf( '\tDownloading from http://bigwww.epfl.ch ...\n');
for ind = 1:6
    websave( filenames{ind}, ...
    sprintf( 'http://bigwww.epfl.ch/deconvolution/bio/%s', filenames{ind} ) );
end

fprintf( '\tUncompressing files...\n' );
for ind = 1:6
    unzip( filenames{ind} );
end

fprintf( '\tRemoving zip files...\n' );
for ind = 1:6
    delete( filenames{ind} );
end

fprintf( 'Done. \n' );

